#include <stdio.h>
#include <SDL.h>
#include <SDL_rect.h>
#include <time.h>
#include <stdbool.h>
#define ScreenX 1000
#define ScreenY 1000
#define IDLE 0
#define RAISE 1
#define STEADY 2
#define LOWER 3






int birdColor[] = { 107,142,35 };
int cactusColor[] = {107,142,35};
int skyColor[] = {204,255,255};
int grassColor[] = {51, 153, 102};

bool printbird = false;
bool printCactus = false;
int timeCounter;

int birdCounter = 0; 
int cactusCounter;

bool stopBird = false;
bool stopCactus = false;
int Situation = 0; // 0(IDLE), 1(RAISE), 2(STEADY), 3(LOWER)

void SDL_Delay(Uint32 ms);

void hitBox(int dinoX, int dinoY, int dinoWidth, int dinoHeight, int  objectX, int objectY, int birdWidth, int birdHeight ) {


    int dinoRight= dinoX + dinoWidth;
    int dinoButtom = dinoY + dinoHeight;

    int objectRight = objectX + birdWidth;
    int objectButtom= objectY + birdHeight;




    if (((dinoRight >= objectX && dinoRight <= objectRight) || (dinoX >= objectX && dinoX <= objectRight)) && // bird from right or bird from left
        (
            ((dinoY >= objectButtom && dinoY <= objectY) || (dinoButtom <= objectButtom && dinoButtom >= objectY)) || //bird form above or bird from below
            (dinoY <= objectButtom && dinoButtom >= objectY)   //bird from middle right
            )
        )
    {
          
        stopBird = true;
        stopCactus = true;

        birdColor[0] = 255;
        skyColor[0] = skyColor[1] = skyColor[2] = 211;
        grassColor[0] = grassColor[1] = grassColor[2] = 128;

    }

}

int main(int argc, char* args[]) {
  
    srand(time(0));
    cactusCounter = rand() % 20 + 10;
    birdCounter = rand() % 20 + 10; 


    if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
        printf("error initializing SDL: %s\n", SDL_GetError());
    }
    SDL_Window* win = SDL_CreateWindow("GAME", // creates a window
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED, ScreenX, ScreenY, 0);

    SDL_Surface* PrimarySurface = SDL_GetWindowSurface(win);
    // triggers the program that controls
    // your graphics hardware and sets flags
    Uint32 render_flags = SDL_RENDERER_ACCELERATED;

    // creates a renderer to render our images
    SDL_Renderer* rend = SDL_CreateRenderer(win, -1, render_flags);


    SDL_RenderClear(rend);
    int PIXEL = ScreenX / 8;

    int GrassHeight = PIXEL*1;  //Grass
    int GrassWidth = ScreenX;
    int GrassY = ScreenY - GrassHeight;


    int SkyHeight = ScreenY - GrassHeight; //Sky
    int SkyWidth = ScreenX;   
    

    int DinoHeight = PIXEL*2;  //Dino
    int DinoWidth = PIXEL*1;
    int DinoX = PIXEL*1;
    int DinoY = GrassY - DinoHeight;


    int birdHeight = PIXEL*1; // Bird
    int birdWidth = PIXEL*1;
    int birdX = ScreenX - birdWidth;
    int birdY = GrassY - PIXEL*3;


    int cactusHeight = DinoHeight;
    int cactusWidth = DinoWidth;
    int cactusY = DinoY;
    int cactusX = ScreenX - cactusWidth;


    int adder = PIXEL*1;
    bool jumping = false;
    while (true) {


        SDL_RenderPresent(rend);


        SDL_SetRenderDrawColor(rend, skyColor[0], skyColor[1], skyColor[2], 255);     //the sky
        SDL_Rect sky;
        sky.x = 0;
        sky.y = 0;
        sky.w = SkyWidth;
        sky.h = SkyHeight;
        SDL_RenderFillRect(rend, &sky);


        SDL_SetRenderDrawColor(rend, grassColor[0], grassColor[1], grassColor[2], 255); // the grass
        SDL_Rect grass;
        grass.x = 0;
        grass.y = GrassY;
        grass.w = GrassWidth;
        grass.h = GrassHeight;
        SDL_RenderFillRect(rend, &grass);


        SDL_SetRenderDrawColor(rend, 0, 0, 0, 255); // the dino
        SDL_Rect dino;
        dino.x = DinoX;    
        dino.y = DinoY;
        dino.w = DinoWidth;
        dino.h = DinoHeight;
        SDL_RenderFillRect(rend, &dino);

        if (printCactus) {

            if (!stopCactus)
                cactusX -= PIXEL*1;

            SDL_SetRenderDrawColor(rend, cactusColor[0], cactusColor[1], cactusColor[2], 255); // the cactus
            SDL_Rect cactus;
            cactus.x = cactusX;
            cactus.y = cactusY;
            cactus.w = cactusWidth;
            cactus.h = cactusHeight;
            SDL_RenderFillRect(rend, &cactus);


            if ((cactusX) <=0) {  //if the cactus goes outside
                printCactus= false; //stop printing
                cactusX = ScreenX - cactusWidth; //reset the values
                cactusCounter = rand()%20 + 10;
            }

            hitBox(dino.x, dino.y, dino.w, dino.h, cactus.x, cactus.y, cactus.w, cactus.h);

        }
        else {
            cactusCounter--; 
            if (cactusCounter == 0) {
                printCactus = true; 
            }
        }

        if (printbird) {

            if (!stopBird)
                birdX -= PIXEL*1;

            SDL_SetRenderDrawColor(rend, birdColor[0], birdColor[1], birdColor[2], 255); // the bird
            SDL_Rect bird;
            bird.x = birdX;
            bird.y = birdY;
            bird.w = birdWidth;
            bird.h = birdHeight;
            SDL_RenderFillRect(rend, &bird);
           
            


            if ((birdX) <= 0) {  //if the bird goes outside
                printbird = false; //stop printing
                birdX = ScreenX - birdWidth; //reset the values
                birdCounter = rand() % 20 + 10;
            }


            hitBox(dino.x, dino.y, dino.w, dino.h, bird.x, bird.y, bird.w, bird.h);


          /*  int dinoxw = dino.x + DinoWidth;
            int birdxw = bird.x + birdWidth;
            int dinoyh = dino.y + DinoHeight;
            int birdyh = bird.y + birdHeight;*/

            //if ( ((dinoxw >= bird.x && dinoxw <= birdxw) || ( dino.x >= birdX && dino.x <= birdxw))&& // bird from right or bird from left
            //     (
            //      ((dino.y >= birdyh && dino.y <= bird.y)|| (dinoyh <= birdyh &&  dinoyh >= bird.y)) || //bird form above or bird from below
            //      (dino.y <= birdyh && dinoyh >= bird.y)   //bird from middle right
            //     ) 
            //   ){

            //    stopBird = true;
            //    birdColor[0] = 255;
            //    skyColor[0] = skyColor[1] = skyColor[2] = 211;
            //    grassColor[0] = grassColor[1] = grassColor[2] = 128;
            //}
        }
        else {
            birdCounter--;
            if (birdCounter== 0) {
                printbird = true;
            }
        }


        SDL_Event event;
        SDL_PollEvent(&event);


        if (event.type == SDL_QUIT)
            break;
        if (event.type == SDL_KEYDOWN)  //if space pressed
        {
            switch (event.key.keysym.scancode) {
            case SDL_SCANCODE_W:
            case SDL_SCANCODE_SPACE:
                timeCounter = 10;
                jumping = true; 
                printbird = true;
            default:
                break;
            }
           
        }



        switch (Situation) {

            case IDLE:           
                if (jumping) {
                    Situation++;
                }
                break;
            case RAISE:         
                DinoY -= PIXEL;
                if (DinoY == PIXEL*1)
                    Situation++;
                break;
            case STEADY:            
                timeCounter--;
                if (timeCounter == 0)
                    Situation++;
                break;
            case LOWER:            
                DinoY += PIXEL;
                if (DinoY == GrassY - DinoHeight)
                    Situation = 0;
                jumping = false; 
                break;
        }

     

        SDL_Delay(100);

    }

    // destroy texture
    //SDL_DestroyTexture(tex);

    // destroy renderer
    SDL_DestroyRenderer(rend);

    // destroy window
    SDL_DestroyWindow(win);

    // close SDL
    SDL_Quit();




	return 0;
}